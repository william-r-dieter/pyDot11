import pyDot11

class Pcap(object):
    """Class to deal with pcap specific tasks"""
    
    def crypt2plain(self, pcapFile, key):
        """Converts an encrypted pcap to unencrypted pcap
        Returns the unencrypted pcap input as a scapy PacketList object
        """
        pcapList = []
        pObj = pyDot11.rdpcap(pcapFile)
        for i in range(len(pObj)):
            try:
                pkt, iv = pyDot11.wepDecrypt(pObj[i], key)
            except:
                pkt = pObj[i].copy()
            
            pcapList.append(pkt)
            
        title = pcapFile.replace('.pcap', '_decrypted.pcap')
        pyDot11.wrpcap(title, pcapList)
        print 'Decrypted pcap written to: %s' % title
        
        packetList = pyDot11.plist.PacketList(res = pcapList)
        return packetList
