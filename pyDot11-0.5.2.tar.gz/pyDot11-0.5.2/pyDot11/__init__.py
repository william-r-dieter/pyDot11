# Copyright (C) 2016 stryngs

import logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)
from rc4 import rc4
from scapy.all import *
from .lib.ccmp import Ccmp, ccmpSomething
from .lib.tkip import Tkip, tkipSomething
from .lib.wep import Wep
from .lib.handshake import Handshake
from .lib.nic import Tap
from .lib.utils import Pcap


## WEP PORTION
def wepDecrypt(pkt, keyText):
    """Encompasses the steps needed to decrypt a WEP packet"""
    stream, iVal, seed = wepCrypto.decoder(pkt, keyText)
    
    ## Decode the [LLC]
    decodedPacket = wepCrypto.deBuilder(pkt, stream)

    ## Flip FCField bits accordingly
    if decodedPacket[Dot11].FCfield == 65L:
        decodedPacket[Dot11].FCfield = 1L
    elif decodedPacket[Dot11].FCfield == 66L:
        decodedPacket[Dot11].FCfield = 2L
    
    return decodedPacket, iVal


def wepEncrypt(pkt, keyText, iVal = '\xba0\x0e', ):
    """Encompasses the steps needed to encrypt a WEP packet"""
    pkt = pkt.copy()
       
    ## Encode the LLC layer via rc4
    stream = wepCrypto.encoder(pkt, iVal, keyText)

    ## Build the packet minus the FCS
    encodedPacket = wepCrypto.enBuilder(pkt, stream, iVal)
    
    ## Flip FCField bits accordingly
    if encodedPacket[Dot11].FCfield == 1L:
        encodedPacket[Dot11].FCfield = 65L
    elif encodedPacket[Dot11].FCfield == 2L:
        encodedPacket[Dot11].FCfield = 66L
    
    ## Add the ICV
    encodedPacket[Dot11WEP].icv = int(wepCrypto.endSwap(hex(crc32(str(\
        encodedPacket[Dot11])[0:-4]) & 0xffffffff)), 16)
    
    return encodedPacket



## WPA PORTION
def wpaDecrypt(pkt, psk):
    """Encompasses the steps needed to decrypt a WPA packet"""
    pass


### Instantiations
wepCrypto = Wep()
#wpaCrypto = Wpa()
pcap = Pcap()
