from scapy.layers.dot11 import RadioTap, Dot11, Dot11WEP
from scapy.layers.l2 import LLC
from utils import Packet
from zlib import crc32
import binascii, re, struct, sys

## PYPY workaround
try:
    from _PYPY.Cryptodome.Cipher import AES
except:
    from Cryptodome.Cipher import AES

class Ccmp(object):
    """All things WPA related"""

    def __init__(self):
        self.p = Packet()

    def toDS(self, pkt):
        return pkt[Dot11].FCfield & 0x1 > 0

    def fromDS(self, pkt):
        return pkt[Dot11].FCfield & 0x2 > 0

    def moreFrag(self, pkt):
        return pkt[Dot11].FCfield & 0x4 > 0

    def order(self, pkt):
        return pkt[Dot11].FCfield & 0x128 > 0

    def fragNum(self, pkt):
        if sys.byteorder == 'little':
            return pkt[Dot11].SC & 0xf
        else:
            return (pkt[Dot11].SC >> 8) & 0xf

    def bcopy(self, src, dst, src_offset, dst_offset):
        for i in range(0, len(src)):
            dst[i + dst_offset] = src[i + src_offset]

    def xorRange(self, src1, src2, dst, sz):
        for i in range(0, sz):
            dst[i] = src1[i] ^ src2[i]
        return bytearray(dst)

    ## Here we must find if the packet has FCS. This isn't easy because this field isn't always in the same place.
    def hasFCS(self, pkt):

        ## These bits are relative to a single byte, not 4 bytes.
        TSFT = 1 << 0
        FCS  = 1 << 4
        Ext  = 1 << 7

        pktbytes = bytearray(str(pkt))

        ## If packet has TSFT we have to skip that field later on to find Flags
        hasTSFT = bool(pktbytes[4] & TSFT)

        ## Start seaching for Flags on byte 8
        i = 7
        hasExt = pktbytes[i] & Ext

        ## Skip extra present flags that may be present
        if hasExt:
            radiotap_len = pktbytes[2]
            while i < radiotap_len:
                hasExt = pktbytes[i] & Ext
                if not hasExt:
                    break
                i += 4
        else:
            i += 1

        ## Skip MAC timestamp
        if hasTSFT:
            i += 9

        ## Flags are here
        flags = pktbytes[i]

        if flags & FCS:
            #print 'Packet has FCS'
            return True
        else:
            #print 'Packet has NO FCS'
            return False


    def decrypt(self, pkt, tk):
        """Decrypt the packet"""

        ## If the packet has FCS, it should be removed and added later on.
        if self.hasFCS(pkt):
            pload = self.p.byteRip(pkt[Dot11WEP],
                                   order = 'last',
                                   qty = 4,
                                   chop = True,
                                   output = 'str')
        else:
            pload = str(pkt[Dot11WEP])

        dot11 = pkt[Dot11]
        MIC = bytearray(16)
        PN = bytearray(6)

        ## Get the IV
        PN[0] = pload[7]
        PN[1] = pload[6]
        PN[2] = pload[4]
        PN[3] = pload[5]
        PN[4] = pload[1]
        PN[5] = pload[0]

        ## AAD is used to generate the MIC, it has to be filled with some packet data.
        AAD = bytearray(32)
        AAD[0] = 0
        AAD[1] = 22 + 6*int(self.fromDS(pkt) and self.toDS(pkt))
        if dot11.subtype == 8:
            AAD[1] += 2

        AAD[2] = dot11.proto | (dot11.type << 2) | ((dot11.subtype << 4) & 0x80)
        AAD[3] = 0x40 | self.toDS(pkt) | (self.fromDS(pkt) << 1) | (self.moreFrag(pkt) << 2) | (self.order(pkt) << 7)
        self.bcopy(bytearray(re.sub(':','', dot11.addr1).decode("hex")), AAD, 0, 4)
        self.bcopy(bytearray(re.sub(':','', dot11.addr2).decode("hex")), AAD, 0, 10)
        self.bcopy(bytearray(re.sub(':','', dot11.addr3).decode("hex")), AAD, 0, 16)

        AAD[22] = self.fragNum(pkt)
        AAD[23] = 0

        if self.fromDS(pkt) and self.toDS(pkt):
            bcopy(bytearray(re.sub(':','', dot11.addr4).decode("hex")), AAD, 0, 24)

        ## DEBUG
        #print "".join("{:02x} ".format(e) for e in AAD)

        ## Create a new AES cypher from the TK, which will be used to decrypt the packet
        cypher = AES.new(str(tk), AES.MODE_ECB)

        crypted_block = [0]*16
        total_sz = len(pload) - 16
        offset = 8
        blocks = (total_sz + 15) / 16

        ## DEBUG
        #print("%d %d %d" % (total_sz, offset, blocks))

        counter = bytearray(16)
        counter[0] = 0x59
        counter[1] = 0
        self.bcopy(bytearray(re.sub(':','', dot11.addr2).decode("hex")), counter, 0, 2)
        self.bcopy(PN, counter, 0, 8)
        counter[14] = (total_sz >> 8) & 0xff
        counter[15] = total_sz & 0xff
        
        ## DEBUG
        #print "".join("{:02x} ".format(e) for e in counter)

        MIC = bytearray(cypher.encrypt(str(counter)))
        MIC = self.xorRange(MIC, AAD, MIC, 16)
        MIC = bytearray(cypher.encrypt(str(MIC)))
        MIC = self.xorRange(MIC, AAD[16:], MIC, 16)
        MIC = bytearray(cypher.encrypt(str(MIC)))

        counter[0] = 1
        counter[14] = 0
        counter[15] = 0
        crypted_block = cypher.encrypt(str(counter))
        nice_MIC = bytearray(pload[total_sz+8:])
        nice_MIC = self.xorRange(bytearray(crypted_block), nice_MIC, nice_MIC, 8)

        ## Decrypt packet with CCMP
        decrypted = ''
        for i in range(1, blocks+1):
            if (i == blocks+1):
                block_sz = total_sz % 16
            else:
                block_sz = 16
            counter[14] = (i >> 18) & 0xff
            counter[15] = i & 0xff
            crypted_block = cypher.encrypt(str(counter))

            pload1 = bytearray(pload[offset:])
            pload2 = bytearray(pload[(i - 1) * 16:])
            cb = bytearray(crypted_block)
            self.xorRange(cb, pload1, pload2, block_sz)

            self.xorRange(MIC, pload2, MIC, block_sz)
            MIC = bytearray(cypher.encrypt(str(MIC)))

            decrypted += pload2[:block_sz]
            offset += block_sz

        decrypted += pload2[block_sz:]

        return pkt, decrypted



class ccmpSomething(object):
    
    def __init__(self):
        self.p = Packet()
    

    def deBuilder(self, tgtPkt, decrypted):
        """Return the decrypted packet"""
        
        ## This is our encrypted data we need to remove
        eData = self.p.byteRip(tgtPkt[Dot11WEP].wepdata,
                               qty = 4,
                               chop = True)



        ## This is our decrypted everything, LLC included
        dEverything = self.p.byteRip(decrypted,
                                     qty = 16,
                                     order = 'last',
                                     chop = True)
        


        ## Prep the new pkt
        newPkt = tgtPkt.copy()
        del newPkt[Dot11WEP].wepdata
        
        ## Remove the last four bytes of new pkt and unhexlify
        postPkt = RadioTap((self.p.byteRip(newPkt.copy(),
                                           chop = True,
                                           order = 'last',
                                           output = 'str',
                                           qty = 4)))
        del postPkt[Dot11WEP]

        ## The data is proper in here
        finalPkt = postPkt.copy()/LLC(binascii.unhexlify(dEverything.replace(' ', '')))
       

        ## Flip FCField bits accordingly
        if finalPkt[Dot11].FCfield == 65L:
            finalPkt[Dot11].FCfield = 1L
        elif finalPkt[Dot11].FCfield == 66L:
            finalPkt[Dot11].FCfield = 2L

        ## Calculate and append the FCS
        crcle=crc32(str(finalPkt[Dot11])) & 0xffffffff

        if sys.byteorder == "little":
            
            ## Convert to big endian
            crc = struct.pack('<L', crcle)
            ## Convert to long
            (fcsstr,) = struct.unpack('!L', crc)

        ### Need to research which NIC causes /Raw(fcs) to be needed
        #fcs = bytearray.fromhex('{:32x}'.format(fcsstr))
        #return finalPkt/Raw(fcs)
        return finalPkt
